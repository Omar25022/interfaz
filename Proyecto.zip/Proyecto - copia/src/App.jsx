import { useState } from "react";

export default function HotelApp() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [credentials, setCredentials] = useState({ user: "", pass: "" });

  const [rooms, setRooms] = useState([
    { id: 1, name: "Suite Presidencial", type: "Suite", price: 250, available: 3 },
    { id: 2, name: "Habitación Doble", type: "Doble", price: 120, available: 5 },
    { id: 3, name: "Habitación Sencilla", type: "Sencilla", price: 80, available: 8 },
  ]);

  const [reservations, setReservations] = useState([]);
  const [form, setForm] = useState({
    nombre: "",
    fecha: "",
    habitacion: "",
    metodoPago: "",
    dias: 1,
    documento: "", // 📞 Nuevo campo para DUI/Pasaporte/Teléfono
  });

  // 🔹 Manejo de login
  const handleLogin = () => {
    if (credentials.user === "admin" && credentials.pass === "1234") {
      setLoggedIn(true);
    } else {
      alert("Credenciales incorrectas. Usuario: admin / Contraseña: 1234");
    }
  };

  // 🔹 Crear reserva
  const handleReserve = () => {
    if (!form.nombre || !form.fecha || !form.habitacion || !form.metodoPago || !form.documento) {
      alert("⚠ Debes completar todos los campos.");
      return;
    }

    const roomIndex = rooms.findIndex((r) => r.id === parseInt(form.habitacion));
    if (roomIndex !== -1 && rooms[roomIndex].available >= form.dias) {
      // Ensure enough rooms are available for the requested days
      const totalPrice = rooms[roomIndex].price * form.dias;

      setReservations([
        ...reservations,
        {
          id: Date.now(),
          nombre: form.nombre,
          fecha: form.fecha,
          habitacion: rooms[roomIndex].name,
          price: totalPrice,
          metodoPago: form.metodoPago,
          dias: form.dias,
          documento: form.documento, // 📞 Guarda el número de documento
        },
      ]);

      // Update available rooms
      const updatedRooms = [...rooms];
      updatedRooms[roomIndex].available -= form.dias; // Subtract reserved days
      setRooms(updatedRooms);

      setForm({
        nombre: "",
        fecha: "",
        habitacion: "",
        metodoPago: "",
        dias: 1,
        documento: "", // 📞 Limpia el campo de documento
      });
    } else {
      alert(`No hay suficientes habitaciones disponibles para ${form.dias} días.`);
    }
  };

  // 🔹 Cancelar reserva
  const handleCancel = (id) => {
    const reserva = reservations.find((r) => r.id === id);
    if (!reserva) return;

    // devolver disponibilidad
    const updatedRooms = rooms.map((room) =>
      room.name === reserva.habitacion ? { ...room, available: room.available + reserva.dias } : room
    );
    setRooms(updatedRooms);

    // quitar de reservas
    setReservations(reservations.filter((r) => r.id !== id));
  };

  // 🔹 Calcular ingresos totales
  const totalIngresos = reservations.reduce((sum, res) => sum + res.price, 0);

  // 🔹 Vista Login
  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-6 rounded-xl shadow-lg w-80">
          <h2 className="text-2xl font-bold mb-4 text-center">🔑 Login Empleado</h2>
          <input
            type="text"
            placeholder="Usuario"
            className="w-full border p-2 rounded mb-3"
            value={credentials.user}
            onChange={(e) => setCredentials({ ...credentials, user: e.target.value })}
          />
          <input
            type="password"
            placeholder="Contraseña"
            className="w-full border p-2 rounded mb-3"
            value={credentials.pass}
            onChange={(e) => setCredentials({ ...credentials, pass: e.target.value })}
          />
          <button
            onClick={handleLogin}
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
          >
            Iniciar Sesión
          </button>
        </div>
      </div>
    );
  }

  // 🔹 Vista principal
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">
        🏨 Sistema de Reservas de Hotel
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Inventario */}
        <div className="col-span-1">
          <h2 className="text-xl font-bold mb-3">📦 Habitaciones disponibles</h2>
          <ul className="space-y-2">
            {rooms.map((room) => (
              <li key={room.id} className="bg-white p-3 rounded shadow">
                <p className="font-semibold">{room.name}</p>
                <p>Tipo: {room.type}</p>
                <p>Precio por noche: ${room.price}</p>
                <p>Disponibles: {room.available}</p>
              </li>
            ))}
          </ul>
        </div>

        {/* Formulario */}
        <div className="col-span-1">
          <h2 className="text-xl font-bold mb-3">📝 Nueva Reservación</h2>
          <div className="bg-white p-4 rounded shadow space-y-3">
            <input
              type="text"
              placeholder="Nombre del cliente"
              className="w-full border p-2 rounded"
              value={form.nombre}
              onChange={(e) => setForm({ ...form, nombre: e.target.value })}
            />
            <input
              type="date"
              className="w-full border p-2 rounded"
              value={form.fecha}
              onChange={(e) => setForm({ ...form, fecha: e.target.value })}
            />

            {/* 📞 Campo para número de documento */}
            <input
              type="text"
              placeholder={`Número de Documento (DUI/Pasaporte/Teléfono)`}
              className="w-full border p-2 rounded"
              value={form.documento}
              onChange={(e) => setForm({ ...form, documento: e.target.value })}
            />
            <select
              className="w-full border p-2 rounded"
              value={form.habitacion}
              onChange={(e) => setForm({ ...form, habitacion: e.target.value })}
            >
              <option value="">Seleccionar habitación</option>
              {rooms.map((room) => (
                <option key={room.id} value={room.id}>
                  {room.name}
                </option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Días de estadía"
              min="1"
              className="w-full border p-2 rounded"
              value={form.dias}
              onChange={(e) => setForm({ ...form, dias: parseInt(e.target.value) || 1 })}
            />
            <select
              className="w-full border p-2 rounded"
              value={form.metodoPago}
              onChange={(e) => setForm({ ...form, metodoPago: e.target.value })}
            >
              <option value="">Método de pago</option>
              <option value="Tarjeta">Tarjeta</option>
              <option value="Efectivo">Efectivo</option>
              <option value="Transferencia">Transferencia</option>
            </select>
            <button
              onClick={handleReserve}
              className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
            >
              Reservar
            </button>
          </div>
        </div>

        {/* Reservaciones */}
        <div className="col-span-1">
          <h2 className="text-xl font-bold mb-3">📋 Reservaciones</h2>
          <ul className="space-y-3">
            {reservations.map((res) => (
              <li key={res.id} className="bg-white p-3 rounded shadow">
                <p className="font-semibold">{res.nombre}</p>
                <p>📅 Fecha: {res.fecha}</p>
                <p>🛏 Habitación: {res.habitacion}</p>
                {/* 📞 Muestra el tipo y número de documento */}
                <p>
                  Documento: {res.documento}
                </p>
                <p>💳 Pago: {res.metodoPago}</p>
                <p>⏳ Días: {res.dias}</p>
                <p>💵 Total: ${res.price}</p>
                <button
                  onClick={() => handleCancel(res.id)}
                  className="mt-2 bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                >
                  Cancelar
                </button>
              </li>
            ))}
          </ul>

          {/* Ingresos totales */}
          <div className="mt-4 bg-yellow-100 p-3 rounded shadow text-center">
            <h3 className="text-lg font-bold">💰 Ingresos Totales</h3>
            <p className="text-2xl font-semibold text-green-700">${totalIngresos}</p>
          </div>
        </div>
      </div>
    </div>
  );
}